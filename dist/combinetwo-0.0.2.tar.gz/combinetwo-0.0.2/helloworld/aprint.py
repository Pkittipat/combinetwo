def say_hello_a(name=None):
    if name == None:
        return 'Hello, World! A'
    else:
        return f'Hello, {name}! A'