def say_hello_d(name=None):
    if name == None:
        return 'Hello, World! D'
    else:
        return f'Hello, {name}! D'