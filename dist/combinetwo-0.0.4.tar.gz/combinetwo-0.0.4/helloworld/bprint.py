def say_hello_b(name=None):
    if name == None:
        return 'Hello world! B'
    else:
        return f'Hello, {name}!B'